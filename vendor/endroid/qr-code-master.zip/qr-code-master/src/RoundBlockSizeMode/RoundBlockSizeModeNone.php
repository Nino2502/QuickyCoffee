<?php

declare(strict_types=1);

namespace Endroid\QrCode\RoundBlockSizeMode;

final class RoundBlockSizeModeNone implements RoundBlockSizeModeInterface
{
}
